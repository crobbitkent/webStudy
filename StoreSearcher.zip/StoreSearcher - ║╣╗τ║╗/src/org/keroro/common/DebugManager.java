package org.keroro.common;

public class DebugManager {
	
	
	public static void printDebug(String str) {
		System.out.println("[debug : " + str + " ]");
	}
}
